# Variable Declaration And Use.

###### Declaration
```
<Data type> a
//Or
$a = Any()
///Similar to
Any a = new Any()

// Nullable variables
$b;

// Nullable variables
/**
* This is there since we already support nullables
* i.e (<Data type > | null) $a
*/
(<Data type> | <Data type) $b;
```

###### Usage;

```
func b(Int a, $f) {
	$b =  a + f
}


```
