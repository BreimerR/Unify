# Arithmetic's




###### Mathematical order of executions 
```
(1 + 2) (root(4))
1 + 2 = 3
root(4) =  2
3+2 = 5
```