# Trait Classes
- This is like an interface but can define method bodies
- They can inherit a class and can also inherit an interface
- They can not be initialized as a class

```
interface A{
	$age
}

trait A :: A{
	$age
	
	__setter(name, value){
		 when {
		 	name ->
		 	"breimer": {
		 	
		 	}		 
		 	" ": {
		 		
		 	}
		 }
	}
	
	// if it is one value private
	
	private String name{
			
	}
	
}

trait B: A{
	__setter(String name, value){
    		 when(name){
    		 		"breimer":{
    		 			
    		 		}
    		 }
    	}
}

// Trait usage
class C use A{

}
```