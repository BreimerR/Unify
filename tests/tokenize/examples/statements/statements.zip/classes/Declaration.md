# Classes Declaration

### Declaration
###### _Simple class_
```
class A{
	// <Unify class Body>
}
```
###### _Without a body_

###### _ Class with one method
```
class A 
	name (){
		
	}
```
```
class A
```

##### Final class

```
// This we use finalize an open class
final class A : B;

// delcaring a simpel final class;
final class B{

}
```

##### Class Inheritance

```
class A{
	// <Unify class body> 	
}

class B: A{
	// <Unify class body> 
}
```


