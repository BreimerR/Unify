# Interface
- Defines the class structure and can not have function body

